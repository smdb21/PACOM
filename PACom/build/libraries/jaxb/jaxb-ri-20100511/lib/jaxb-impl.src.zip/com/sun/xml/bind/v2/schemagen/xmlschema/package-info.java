@com.sun.xml.txw2.annotation.XmlNamespace("http://www.w3.org/2001/XMLSchema")
package com.sun.xml.bind.v2.schemagen.xmlschema;
