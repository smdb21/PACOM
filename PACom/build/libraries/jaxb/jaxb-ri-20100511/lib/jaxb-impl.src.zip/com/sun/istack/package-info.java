/**
 * istack-commons runtime utilities.
 */
package com.sun.istack;