
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlNsForm;
import javax.xml.bind.annotation.XmlSchema;
import com.sun.codemodel.JAnnotationWriter;

public interface XmlSchemaWriter
    extends JAnnotationWriter<XmlSchema>
{


    XmlSchemaWriter namespace(String value);

    XmlSchemaWriter elementFormDefault(XmlNsForm value);

    XmlSchemaWriter attributeFormDefault(XmlNsForm value);

    XmlSchemaWriter location(String value);

    XmlNsWriter xmlns();

}
