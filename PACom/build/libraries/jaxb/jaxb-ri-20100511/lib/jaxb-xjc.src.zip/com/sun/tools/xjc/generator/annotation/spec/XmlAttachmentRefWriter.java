
package com.sun.tools.xjc.generator.annotation.spec;

import javax.xml.bind.annotation.XmlAttachmentRef;
import com.sun.codemodel.JAnnotationWriter;

public interface XmlAttachmentRefWriter
    extends JAnnotationWriter<XmlAttachmentRef>
{


}
